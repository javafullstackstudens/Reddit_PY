package com.reddit.pig;


// customize these to match your instance's typeids
enum TypeID {
    INVALID,
    COMMENT,
    ACCOUNT,
    LINK,
    MESSAGE,
    SUBREDDIT,
}
